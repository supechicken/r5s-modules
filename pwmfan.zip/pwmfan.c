#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>

#define TEMP_POLICY_FILE  "/sys/class/thermal/thermal_zone0/policy"
#define CUR_TEMP_FILE     "/sys/class/thermal/thermal_zone0/temp"
#define FAN_LEVEL_FILE    "/sys/class/thermal/cooling_device0/cur_state"

int temp_policy, temp_file, fan_level, kmsg;
char msg_buf[256];

void print_log(void) {
  //write(kmsg, msg_buf, strlen(msg_buf) + 1);
  fwrite(msg_buf, strlen(msg_buf) + 1, 1, stderr);
}

void init_file_ptrs(void) {
  temp_policy = open(TEMP_POLICY_FILE, O_WRONLY);
  temp_file   = open(CUR_TEMP_FILE, O_RDONLY);
  fan_level   = open(FAN_LEVEL_FILE, O_RDWR);
  kmsg        = open("/dev/kmsg", O_WRONLY);
}

void rewind_fds(void) {
  lseek(temp_policy, 0, SEEK_SET);
  lseek(temp_file, 0, SEEK_SET);
  lseek(fan_level, 0, SEEK_SET);
}

int get_value(int fd) {
  char buf[64];

  rewind_fds();
  read(fd, buf, sizeof(buf));

  return atoi(buf);
}

bool sleep_if_we_should(void) {
  time_t cur_time, end_time, interval;
  struct tm *time_struct;

  time(&cur_time);
  time_struct = localtime(&cur_time);

  if (time_struct->tm_hour >= 0 && time_struct->tm_hour < 8) {
    time_struct->tm_hour = 8;
    time_struct->tm_min  = 0;

    end_time = mktime(time_struct);
    interval = end_time - cur_time;

    snprintf(msg_buf, sizeof(msg_buf), "pwmfan: Stop PWM fan for %i seconds\n", (int) interval);
    print_log();

    rewind_fds();
    write(fan_level, "0\n", 3);
    write(temp_policy, "power_allocator\n", 16);
    rewind_fds();

    sleep(interval);

    rewind_fds();
    write(fan_level, "0\n", 3);
    write(temp_policy, "step_wise\n", 16);
    rewind_fds();

    return true;
  }

  return false;
}

int main(int argc, char **argv) {
  // daemonize
  pid_t pid = fork();
  if (pid != 0) exit(0);
  signal(SIGCHLD, SIG_IGN);
  signal(SIGHUP, SIG_IGN);
  setsid();

  init_file_ptrs();

  int prev_level = 0, cur_level;

  while (1) {
    cur_level = get_value(fan_level);

    if (prev_level != cur_level) {
      snprintf(msg_buf, sizeof(msg_buf), "pwmfan: Fan level changed from %i to %i\n", prev_level, cur_level);
      print_log();

      prev_level = cur_level;
    }

    if (!sleep_if_we_should()) sleep(5);
  }

  return 0;
}
